﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace fl_compare
{
    public partial class Form1 : Form
    {
        int threshold = 5;

        public Form1()
        {
            InitializeComponent();
            textBox4.Text = threshold.ToString();
            file1_fl = "";
            file2_fl = "";
        }

        public string file1_fl, file2_fl;

        private void button2_Click(object sender, EventArgs e)
        {
            if (openFileDialog1.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                System.IO.StreamReader sr = new
                System.IO.StreamReader(openFileDialog1.FileName);
                file2_fl = openFileDialog1.FileName;
                textBox2.Text = file2_fl;
                sr.Close();
            }
        }

  
        public static bool first_file = false;

        private void button3_Click(object sender, EventArgs e)
        {
            if ((file1_fl == "") || (file2_fl == "") || (file1_fl.Substring(Math.Max(0, file1_fl.Length - 4)) != ".bmp") || (file2_fl.Substring(Math.Max(0, file2_fl.Length - 4)) != ".bmp"))
            {
                MessageBox.Show("You need to load .bmp images");
            }
            else
            {
                MessageBox.Show("Your fluorescence levels are being compared. Please stand by.", "Please wait", MessageBoxButtons.OK, MessageBoxIcon.Error);
                //  Console.WriteLine(System.IO.Directory.GetCurrentDirectory());
                File.WriteAllText(System.IO.Directory.GetCurrentDirectory() + "/1a.txt", String.Empty);
                File.WriteAllText(System.IO.Directory.GetCurrentDirectory() + "/2a.txt", String.Empty);
                string path = file1_fl;
                string path2 = file2_fl;
                //INTERPRET GRAPHS FROM MASS-SPEC (maybe?)

                Bitmap bmpSrc = new Bitmap(path, true);
                ConsoleWriteImage(bmpSrc);
                first_file = true;
                Bitmap bmpSrc1 = new Bitmap(path2, true);
                ConsoleWriteImage(bmpSrc1);

                //---- 
                richTextBox1.Text = richTextBox1.Text +  "READING FROM FILE 1 (Original) ";
                string a = File.ReadAllText(System.IO.Directory.GetCurrentDirectory() + "/1a.txt");
                richTextBox1.Text = richTextBox1.Text + "READING FROM FILE 2 (Mutation) ";
                string b = File.ReadAllText(System.IO.Directory.GetCurrentDirectory() + "/2a.txt");
                int distance = Damerau_Levenshtein_Alg(a, b);
                Console.WriteLine("Distance between FILE 1 and FILE 2: " + distance);

                if (distance > threshold)
                {
                    MessageBox.Show("PASSWORDS DO NOT MATCH. ACCESS DENIED");
                }
                else
                {
                    MessageBox.Show("THRESHOLD MATCHED. ACCESS ALLOWED");
                }


                Console.ReadLine();
            }
        }


        private void button1_Click(object sender, EventArgs e)
        {
            if (openFileDialog1.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                System.IO.StreamReader sr = new
                System.IO.StreamReader(openFileDialog1.FileName);
                file1_fl = openFileDialog1.FileName;
                textBox1.Text = file1_fl;
                sr.Close();
            }
        }

        static int[] cColors = { 0x000000, 0x000080, 0x008000, 0x008080, 0x800000, 0x800080, 0x808000, 0xC0C0C0, 0x808080, 0x0000FF, 0x00FF00, 0x00FFFF, 0xFF0000, 0xFF00FF, 0xFFFF00, 0xFFFFFF };
        public void ConsoleWritePixel(Color cValue)
        {

            Color[] cTable = cColors.Select(x => Color.FromArgb(x)).ToArray();
            char[] rList = new char[] { (char)9617, (char)9618, (char)9619, (char)9608 }; 
            int[] bestHit = new int[] { 0, 0, 4, int.MaxValue };

            for (int rChar = rList.Length; rChar > 0; rChar--)
            {
                for (int cFore = 0; cFore < cTable.Length; cFore++)
                {
                    for (int cBack = 0; cBack < cTable.Length; cBack++)
                    {
                        int R = (cTable[cFore].R * rChar + cTable[cBack].R * (rList.Length - rChar)) / rList.Length;
                        int G = (cTable[cFore].G * rChar + cTable[cBack].G * (rList.Length - rChar)) / rList.Length;
                        int B = (cTable[cFore].B * rChar + cTable[cBack].B * (rList.Length - rChar)) / rList.Length;
                        int iScore = (cValue.R - R) * (cValue.R - R) + (cValue.G - G) * (cValue.G - G) + (cValue.B - B) * (cValue.B - B);
                        if (!(rChar > 1 && rChar < 4 && iScore > 50000))
                        {
                            if (iScore < bestHit[3])
                            {
                                bestHit[3] = iScore;
                                bestHit[0] = cFore; 
                                bestHit[1] = cBack; 
                                bestHit[2] = rChar;  
                            }
                        }
                    }
                }
            }
            Console.ForegroundColor = (ConsoleColor)bestHit[0];
            Console.BackgroundColor = (ConsoleColor)bestHit[1];

            if (first_file == false)
            {
                using (StreamWriter sw = File.AppendText(System.IO.Directory.GetCurrentDirectory() + "/1a.txt"))
                {
                    sw.Write(rList[bestHit[2] - 1]);
                }
            }
            else
            {
                using (StreamWriter sw = File.AppendText(System.IO.Directory.GetCurrentDirectory() + "/2a.txt"))
                {
                    sw.Write(rList[bestHit[2] - 1]);
                }
            }

            richTextBox1.Text = richTextBox1.Text + (rList[bestHit[2] - 1]);
        }

        public void ConsoleWriteImage(Bitmap source)
        {
            //calibration 
            int sMax = 40;
            decimal percent = Math.Min(decimal.Divide(sMax, source.Width), decimal.Divide(sMax, source.Height));
            Size dSize = new Size((int)(source.Width * percent), (int)(source.Height * percent));
            Bitmap bmpMax = new Bitmap(source, dSize.Width * 2, dSize.Height);
            for (int i = 0; i < dSize.Height; i++)
            {
                for (int j = 0; j < dSize.Width; j++)
                {
                    ConsoleWritePixel(bmpMax.GetPixel(j * 2, i));
                    ConsoleWritePixel(bmpMax.GetPixel(j * 2 + 1, i));
                }
                richTextBox1.Text = richTextBox1.Text + "\r\n";
            }
            Console.ResetColor();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            threshold = int.Parse(textBox4.Text);
        }

        internal static int Damerau_Levenshtein_Alg(string original, string modified)
        {
            //taken from https://en.wikipedia.org/wiki/Damerau%E2%80%93Levenshtein_distance
            int len_orig = original.Length;
            int len_diff = modified.Length;

            var matrix = new int[len_orig + 1, len_diff + 1];
            for (int i = 0; i <= len_orig; i++)
                matrix[i, 0] = i;
            for (int j = 0; j <= len_diff; j++)
                matrix[0, j] = j;

            for (int i = 1; i <= len_orig; i++)
            {
                for (int j = 1; j <= len_diff; j++)
                {
                    int cost = modified[j - 1] == original[i - 1] ? 0 : 1;
                    var vals = new int[] {
                matrix[i - 1, j] + 1,
                matrix[i, j - 1] + 1,
                matrix[i - 1, j - 1] + cost
            };
                    matrix[i, j] = vals.Min();
                    if (i > 1 && j > 1 && original[i - 1] == modified[j - 2] && original[i - 2] == modified[j - 1])
                        matrix[i, j] = Math.Min(matrix[i, j], matrix[i - 2, j - 2] + cost);
                }
            }
            return matrix[len_orig, len_diff];

            throw new NotImplementedException();
        }

    }
}
