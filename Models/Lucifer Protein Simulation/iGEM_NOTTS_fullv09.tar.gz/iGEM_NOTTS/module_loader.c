#include <string.h>
#include <stdio.h>
#include <stdlib.h>

// gcc -o loader module_loader.c
#define KRED  "\x1B[31m"
#define KBLACK   "\033[30m" 

int main()
{

printf("|- - - - - - - - - - - - - - - - - - - - - - - - - - - - |\n"); 
printf("|Welcome to Lucifer!                                     |\n"); 
printf("|Please keep your code clean and user friendly!          |\n"); 
printf("|Refer back to the iGEM Github and when adding to the    |\n"); 
printf("|toolkit. C is to be used for the interface but feel     |\n"); 
printf("|free to write any code in any language, as long as      |\n"); 
printf("|you come back to this! Have fun and do your best please |\n"); 
printf("|seperate modules by author                              |\n"); 
printf("|- - - - - - - - - - - - - - - - - - - - - - - - - - - - |\n"); 
printf("\n");
printf("\n");
printf("\n");
printf("@iGEM2017 NOTTS Vikram @yourenotsoviolet \n"); 
printf("|- - - - - - - - - - - - - - - - - - - - - - - - - - - - |\n");
printf("%s Type: Lucifer [GFP Protein Conc] [ECHP Protein Conc] [RFP Protein Concentration] [Wavelengths of lasers fired] \n", KRED); 
printf("%s For calculating expected fluorescence  over time given protein parameters and produce spectra \n", KBLACK); 
printf("|- - - - - - - - - - - - - - - - - - - - - - - - - - - - |\n"); 
printf("|- - - - - - - - - - - - - - - - - - - - - - - - - - - - |\n");
printf("\n");
printf("\n");
printf("\n");

float gfp, echp, rfp;
int wv;
printf( "PARAMETERS: [GFP Protein Conc] [ECHP Protein Conc] [RFP Protein Concentration] [Wavelengths of lasers fired] \n");
scanf("%f %f %f %d", &gfp, &echp, &rfp, &wv);
char command[100];
sprintf(command, "/home/violet/iGEM_NOTTS/la %f %f %f %d", gfp, echp, rfp, wv);
printf("%s", command);
system(command);

sprintf(command, "/home/violet/iGEM_NOTTS/lb %f %f %f %d", echp, gfp, rfp, wv);
printf("%s", command);
system(command);

sprintf(command, "/home/violet/iGEM_NOTTS/lc %f %f %f %d", rfp, echp, echp, wv);
printf("%s", command);
system(command);

system("/home/violet/iGEM_NOTTS/lg");


	
    return 0;
}

